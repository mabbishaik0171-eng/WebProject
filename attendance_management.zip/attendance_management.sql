-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 26, 2025 at 04:30 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `attendance_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(10) NOT NULL,
  `username` varchar(15) NOT NULL,
  `aname` varchar(50) NOT NULL,
  `mail` varchar(50) NOT NULL DEFAULT '@mail.com',
  `gender` varchar(10) NOT NULL,
  `password` varchar(15) NOT NULL,
  `apno` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `username`, `aname`, `mail`, `gender`, `password`, `apno`) VALUES
(1, 'suman', 'Suman Prakash', 'aihod@mail.com', 'Male', 'hod', 988888871);

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `class_id` int(10) NOT NULL,
  `subject_id` int(10) NOT NULL,
  `attendance` int(10) NOT NULL,
  `student_id` int(10) NOT NULL,
  `branch` varchar(50) NOT NULL,
  `year` int(10) NOT NULL,
  `sem` int(10) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`class_id`, `subject_id`, `attendance`, `student_id`, `branch`, `year`, `sem`, `date`) VALUES
(405, 201, 77, 1, 'CAI', 3, 1, '2025-09-01');

-- --------------------------------------------------------

--
-- Table structure for table `attendance_record`
--

CREATE TABLE `attendance_record` (
  `subject_id` int(15) NOT NULL,
  `subject_name` varchar(50) NOT NULL,
  `faculty_id` int(15) NOT NULL,
  `faculty_name` varchar(50) NOT NULL,
  `student_id` int(15) NOT NULL,
  `sname` varchar(50) NOT NULL,
  `roll` varchar(10) NOT NULL,
  `year` int(10) NOT NULL,
  `branch` varchar(50) NOT NULL,
  `section` varchar(10) NOT NULL,
  `date` date NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance_record`
--

INSERT INTO `attendance_record` (`subject_id`, `subject_name`, `faculty_id`, `faculty_name`, `student_id`, `sname`, `roll`, `year`, `branch`, `section`, `date`, `status`) VALUES
(201, 'OS', 101, 'Suman Prakash', 1, 'Meghana', '23ATA31040', 3, 'CAI', 'A', '2025-10-26', 'present'),
(201, 'OS', 101, 'Suman Prakash', 14, 'Hima', '23ATA31018', 3, 'CAI', 'A', '2025-10-26', 'present'),
(201, 'OS', 101, 'Suman Prakash', 1, 'Meghana', '23ATA31040', 3, 'CAI', 'A', '2025-10-05', 'absent'),
(201, 'OS', 101, 'Suman Prakash', 14, 'Hima', '23ATA31018', 3, 'CAI', 'A', '2025-10-05', 'absent'),
(201, 'OS', 101, 'Suman Prakash', 1, 'Meghana', '23ATA31040', 3, 'CAI', 'A', '2025-10-01', 'present'),
(201, 'OS', 101, 'Suman Prakash', 14, 'Hima', '23ATA31018', 3, 'CAI', 'A', '2025-10-01', 'absent'),
(202, 'DBMS', 102, 'Janardhan', 1, 'Meghana', '23ATA31040', 3, 'CAI', 'A', '2025-10-26', 'absent'),
(202, 'DBMS', 102, 'Janardhan', 14, 'Hima', '23ATA31018', 3, 'CAI', 'A', '2025-10-26', 'absent'),
(202, 'DBMS', 102, 'Janardhan', 15, 'Mabbi', '23ATA31158', 3, 'CAI', 'C', '2025-10-26', 'present'),
(202, 'DBMS', 102, 'Janardhan', 16, 'Lahari', '23ATA31173', 3, 'CAI', 'C', '2025-10-26', 'present'),
(202, 'DBMS', 102, 'Janardhan', 17, 'Bharathi', '23ATA31177', 3, 'CAI', 'C', '2025-10-26', 'present'),
(202, 'DBMS', 102, 'Janardhan', 1, 'Meghana', '23ATA31040', 3, 'CAI', 'A', '2025-10-25', 'present'),
(202, 'DBMS', 102, 'Janardhan', 14, 'Hima', '23ATA31018', 3, 'CAI', 'A', '2025-10-25', 'present'),
(202, 'DBMS', 102, 'Janardhan', 15, 'Mabbi', '23ATA31158', 3, 'CAI', 'C', '2025-10-25', 'absent'),
(202, 'DBMS', 102, 'Janardhan', 16, 'Lahari', '23ATA31173', 3, 'CAI', 'C', '2025-10-25', 'absent'),
(202, 'DBMS', 102, 'Janardhan', 17, 'Bharathi', '23ATA31177', 3, 'CAI', 'C', '2025-10-25', 'absent'),
(203, 'Python', 104, 'David', 2, 'Indu', '25ATA31093', 1, 'CAI', 'A', '2025-10-26', 'absent'),
(203, 'Python', 104, 'David', 7, 'Himawari', '25ATA05017', 1, 'CSE', 'C', '2025-10-26', 'present'),
(203, 'Python', 104, 'David', 18, 'Thanuja', '25ATA31013', 1, 'CAI', 'A', '2025-10-26', 'present'),
(203, 'Python', 104, 'David', 19, 'Chinna', '25ATA31039', 1, 'CAI', 'A', '2025-10-26', 'present');

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `class_id` int(10) NOT NULL,
  `roll` varchar(10) NOT NULL,
  `year` int(10) NOT NULL,
  `sem` int(10) NOT NULL,
  `branch` varchar(50) NOT NULL,
  `section` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`class_id`, `roll`, `year`, `sem`, `branch`, `section`) VALUES
(405, '23ATA31040', 3, 1, 'CAI', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `faculty_id` int(10) NOT NULL,
  `username` varchar(50) NOT NULL,
  `fname` varchar(30) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `fmail` varchar(30) NOT NULL,
  `fpno` int(10) NOT NULL,
  `password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`faculty_id`, `username`, `fname`, `gender`, `fmail`, `fpno`, `password`) VALUES
(101, 'suman', 'Suman Prakash', 'male', 'suman@gmail.com', 987654321, 'hod'),
(102, 'janardhan', 'Janardhan', 'Male', '102@gmail.com', 1021021020, 'janardhan'),
(103, 'somanna', 'Somanna', 'Male', '103@gmail.com', 1000000003, '103'),
(104, 'david', 'David', 'Male', '104@gmail.com', 1000000004, '104'),
(105, 'lakshmi', 'Swarajya Lakshmi', 'Female', 'lakshmi@gmail.com', 2147483647, 'cvip');

-- --------------------------------------------------------

--
-- Table structure for table `faculty_class`
--

CREATE TABLE `faculty_class` (
  `faculty_id` int(11) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `class_id` int(10) NOT NULL,
  `subject_id` int(10) NOT NULL,
  `year` int(10) NOT NULL,
  `student_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faculty_class`
--

INSERT INTO `faculty_class` (`faculty_id`, `fname`, `class_id`, `subject_id`, `year`, `student_id`) VALUES
(101, 'suman prakash', 405, 201, 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `student_id` int(10) NOT NULL,
  `username` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `roll` varchar(10) NOT NULL,
  `branch` varchar(50) NOT NULL,
  `section` varchar(5) NOT NULL,
  `year` int(10) NOT NULL,
  `sem` int(10) NOT NULL,
  `attendance` int(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phno` int(15) NOT NULL,
  `password` varchar(20) NOT NULL,
  `fee_due` int(10) NOT NULL,
  `address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_id`, `username`, `name`, `roll`, `branch`, `section`, `year`, `sem`, `attendance`, `email`, `phno`, `password`, `fee_due`, `address`) VALUES
(1, 'meghana', 'Meghana', '23ATA31040', 'CAI', 'A', 3, 1, 0, '40@gmail.com', 1236547890, 'megha123', 0, 'kurnool.'),
(2, 'indu', 'Indu', '25ATA31093', 'CAI', 'A', 1, 1, 0, 'indu@gmail.com', 98556836, 'induja', 0, 'Dhone'),
(7, 'hima', 'Himawari', '25ATA05017', 'CSE', 'C', 1, 1, 0, 'hima@gmail.com', 909090909, 'hima', 0, 'Kasukabe'),
(14, 'hima', 'Hima', '23ATA31018', 'CAI', 'A', 3, 1, 0, 'hima18@gmail.com', 2147483647, '123', 0, ''),
(15, 'mabbi', 'Mabbi', '23ATA31158', 'CAI', 'C', 3, 1, 0, 'mabbi@gmail.com', 789856832, 'mabbi', 100, 'Yemmiganur'),
(16, 'lahari', 'Lahari', '23ATA31173', 'CAI', 'C', 3, 1, 0, 'lahari@gmail.com', 895624562, 'lahari', 100, 'Kurnnol'),
(17, 'bharathi', 'Bharathi', '23ATA31177', 'CAI', 'C', 3, 1, 0, 'bharathi@gmail.com', 789657415, 'bharathi', 100, 'Kurnool'),
(18, 'tanu', 'Thanuja', '25ATA31013', 'CAI', 'A', 1, 1, 0, 'tanu@gmail.com', 895459632, 'tanu', 100, 'Dhone'),
(19, 'chinna', 'Chinna', '25ATA31039', 'CAI', 'A', 1, 1, 0, '39@gmail.com', 791894636, 'chinna', 985, 'Nandayal');

-- --------------------------------------------------------

--
-- Table structure for table `studentclass`
--

CREATE TABLE `studentclass` (
  `studentclass_id` int(10) NOT NULL,
  `class_id` int(10) NOT NULL,
  `student_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `studentclass`
--

INSERT INTO `studentclass` (`studentclass_id`, `class_id`, `student_id`) VALUES
(901, 405, 1);

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `subject_id` int(10) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `faculty_id` int(10) NOT NULL,
  `year` int(10) NOT NULL,
  `sem` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`subject_id`, `subject`, `faculty_id`, `year`, `sem`) VALUES
(201, 'OS', 101, 3, 1),
(202, 'DBMS', 102, 3, 1),
(203, 'Python', 104, 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`class_id`),
  ADD UNIQUE KEY `subject_id` (`subject_id`),
  ADD UNIQUE KEY `student_id` (`student_id`);

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`class_id`);

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`faculty_id`);

--
-- Indexes for table `faculty_class`
--
ALTER TABLE `faculty_class`
  ADD PRIMARY KEY (`faculty_id`),
  ADD UNIQUE KEY `student_id` (`student_id`),
  ADD UNIQUE KEY `class_id` (`class_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`student_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `password` (`password`),
  ADD UNIQUE KEY `roll` (`roll`);

--
-- Indexes for table `studentclass`
--
ALTER TABLE `studentclass`
  ADD PRIMARY KEY (`studentclass_id`),
  ADD UNIQUE KEY `student_id` (`student_id`),
  ADD UNIQUE KEY `class_id` (`class_id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`subject_id`),
  ADD UNIQUE KEY `faculty_id` (`faculty_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `class_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=406;

--
-- AUTO_INCREMENT for table `class`
--
ALTER TABLE `class`
  MODIFY `class_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=406;

--
-- AUTO_INCREMENT for table `faculty`
--
ALTER TABLE `faculty`
  MODIFY `faculty_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=107;

--
-- AUTO_INCREMENT for table `faculty_class`
--
ALTER TABLE `faculty_class`
  MODIFY `faculty_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `student_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `studentclass`
--
ALTER TABLE `studentclass`
  MODIFY `studentclass_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=902;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
  ADD CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`subject_id`),
  ADD CONSTRAINT `attendance_ibfk_2` FOREIGN KEY (`student_id`) REFERENCES `student` (`student_id`);

--
-- Constraints for table `class`
--
ALTER TABLE `class`
  ADD CONSTRAINT `class_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `studentclass` (`class_id`);

--
-- Constraints for table `faculty_class`
--
ALTER TABLE `faculty_class`
  ADD CONSTRAINT `faculty_class_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `class` (`class_id`),
  ADD CONSTRAINT `faculty_class_ibfk_2` FOREIGN KEY (`faculty_id`) REFERENCES `faculty` (`faculty_id`);

--
-- Constraints for table `studentclass`
--
ALTER TABLE `studentclass`
  ADD CONSTRAINT `studentclass_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `student` (`student_id`);

--
-- Constraints for table `subjects`
--
ALTER TABLE `subjects`
  ADD CONSTRAINT `subjects_ibfk_1` FOREIGN KEY (`faculty_id`) REFERENCES `faculty` (`faculty_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
